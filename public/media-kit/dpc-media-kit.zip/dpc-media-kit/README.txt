DIA Programming Club (DPC) media kit
https://diapc.dev/media-kit

dpc/      DPC logos (modern (wide), classic), emblem (512 px) and the 1200x630 social banner
awssbg/   AWS Student Builders Group at DIA logos: wordmark (dark and white text), mark (SVG + PNG), lock-up

Name:     DIA Programming Club (short: DPC)
Tagline:  CODE · CREATE · CONNECT
Founded:  21 June 2015, Daffodil International Academy, Dhaka, Bangladesh
Contact:  hi@diapc.dev

Colours
  DPC Blue     #2454d7
  DPC Magenta  #c23b91
  Ink          #17213d
  Paper        #fbfaf7
  Sky tint     #eef2ff
  AWS Orange   #ff9900 (AWS SBG accent)

Usage: keep clear space around logos, do not stretch, recolour or add effects.
AWS and the AWS logo are trademarks of Amazon.com, Inc. or its affiliates. Use AWS marks in line with the AWS trademark guidelines.
